package com.example.thaparconnect.core.enums;

public enum ItemStatus {
    PAID,PROCESSING,LISTED
}
