package com.example.thaparconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThaparConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
