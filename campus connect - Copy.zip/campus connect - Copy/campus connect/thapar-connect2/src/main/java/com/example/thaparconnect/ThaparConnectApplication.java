package com.example.thaparconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThaparConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThaparConnectApplication.class, args);
	}

}
