package com.example.thaparconnect.core.enums;

public enum HostelType {
        A,B,C,D,G,H,I,J,L,M,PG
}
