package com.example.thaparconnect.core.enums;

public enum ItemCategory {
    electronics,clothing
}
